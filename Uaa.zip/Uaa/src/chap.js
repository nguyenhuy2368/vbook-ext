function execute(url) {
    const BASE_COOKIE = "SESSION=OWMzMGJiYjItNTI3ZS00ZGYxLTlkMGYtZjJmM2RjN2Q4OWY5; token=eyJhbGciOiJIUzI1NiJ9.eyJpZCI6MTE5NDgxNzA3NTAzMDM5NjkyOCwidHlwZSI6ImN1c3RvbWVyIiwidGltZXN0YW1wIjoxNzkzNDU0NzcxMjc5LCJzaWQiOiI1OWI1ODk3ZTZhMDA3ZWRlZGI4ZWIyMmEwMDcyYTcyZSIsImV4cCI6MTc5NDA1OTU3MX0.ArBF7JfYNmfs7UC1S_UKi5ZCu0AYnlD93kRTsZ31ceU; cf_clearance=Cj7UuUisvAxN9xKfWppu2YU92T7dBJPXOV4UK9J3oiR18UEl-oeuyufa5Bxyz5cNn0v6KtG4jzE0dwacAKLE8Cxd19CBlLwR9ySE70FyzCCUSZ515F2bCS6-HbOfN7X_wpDmc4nWBf0ON2Q38HtHslkaHrP1Mw9mE_dSoGlw3BKgLn4f7oGMraEX1XcXId6-PvFXD9HuLc5ms0cTy6ifb6Tns8pvj11JBp8asZRoSKuLj3CGHh1OCJGX0rKLl8Yj_UV5EQ2YCxZmtA-FL_e8EasyLJoNU6ECaCpk0PaVM7f88O--Dcbx9IHmIGAsgV0Tq486meckpAhmJ7iCfO6vMDfCfNy6Vntwdkm4D4HcMANDXw_RzLW4P8f1jI2csfd3herr1AOfFAhHDKz1pVCSEqALuLhMwx4vSeQ4sWzz89fMb1vrfidzU_NU; uaa_uvid=882d3fc7162074f632669bf0";
    let body = {
        method: "POST",
        headers: {
            "cookie": BASE_COOKIE,
            "User-Agent": UserAgent.android()
        }
    };

    let response = fetch(url, body);

    if (response.ok) {
        let doc = response.html();
        let content = "";
        console.log(doc);
        doc.select(".line").forEach(e => {
            content += e.text() + "<br>";
        });

        return Response.success(content);
    }
    return null;
}